-- Prize Powder purchases using Unity accolades. No actions until requested.
-- Menu protocol reference: https://gist.github.com/Ivaar/61744cdad6afa2ee8aede758e200496d
local packets=require('packets')
local now=require('socket').gettime
local M={}
local run
local function say(s) windower.add_to_chat(207,'[Prize Powder] '..s) end
local function uint(data,offset,bytes)
    if type(data)~='string' or #data<offset+bytes then return nil end
    local n=0
    for i=bytes-1,0,-1 do n=n*256+data:byte(offset+i+1) end
    return n
end
local function inventory()
    local bag=windower.ffxi.get_items(0) or {}
    local info=windower.ffxi.get_bag_info(0)
    if not info or not info.enabled then return 0,0 end
    local total,partial=0,0
    for _,v in pairs(bag) do
        if type(v)=='table' and v.id==5945 then
            total=total+(v.count or 0)
            if v.status==0 then partial=partial+math.max(0,99-(v.count or 0)) end
        end
    end
    return total,math.max(0,info.max-info.count)*99+partial
end
local function option(value,automated)
    packets.inject(packets.new('outgoing',0x05B,{
        ['Target']=run.id,['Target Index']=run.index,['Zone']=230,['Menu ID']=3529,
        ['Option Index']=value%65536,['_unknown1']=math.floor(value/65536),
        ['Automated Message']=automated}))
end
local function close()
    if run and run.menu then option(0x40000000,false);run.menu=false end
end
local function stop(reason)
    close();run=nil;say(reason)
end
function M.active() return run~=nil end
function M.cancel()
    if run then stop('Stopped. Any purchase already sent may still complete; check Inventory before retrying.') end
end
function M.start(limit)
    if run then say('Already buying; use //accolades cancel to stop.');return end
    local info=windower.ffxi.get_info()
    local p=windower.ffxi.get_player()
    if not info or not info.logged_in or info.zone~=230 then say('Go to Urbiolaine in Southern San d\'Oria.');return end
    if not p or p.status~=0 or info.menu_open then say('Stand idle and close other menus first.');return end
    local npc=windower.ffxi.get_mob_by_name('Urbiolaine')
    if not npc or not npc.is_npc or not npc.valid_target or not npc.distance or npc.distance>36 then
        say('Move within six yalms of Urbiolaine.');return
    end
    local baseline,space=inventory()
    if space<1 then say('Inventory has no room for Prize Powder.');return end
    run={phase='menu',attempt=1,id=npc.id,index=npc.index,baseline=baseline,limit=limit or 7920,deadline=now()+12}
    say('Checking accolades, weekly allowance, and Inventory capacity.')
    packets.inject(packets.new('outgoing',0x01A,{['Target']=npc.id,['Target Index']=npc.index,['Category']=0}))
end
windower.register_event('incoming chunk',function(id,data,modified,injected,blocked)
    if not run or injected or blocked then return end
    if id==0x034 and run.phase=='menu' then
        if uint(data,4,4)~=run.id or uint(data,40,2)~=run.index then return end
        if uint(data,42,2)~=230 or uint(data,44,2)~=3529 then
            run=nil;say('Unexpected Unity menu. Finish any Unity introduction manually, then retry.');return
        end
        run.accolades=uint(data,16,4)
        if not run.accolades or run.accolades>99999 then run=nil;say('Unrecognized accolade value; no purchase sent.');return end
        run.menu=true;run.phase='allowance';run.deadline=now()+12
        option(10,true);return true
    elseif id==0x05C and run.menu then
        if run.phase=='allowance' then
            local allowance=uint(data,16,4)
            if not allowance or allowance>100000 then stop('Unrecognized weekly allowance; no purchase sent.');return end
            local _,space=inventory()
            run.quantity=math.min(math.floor(math.min(run.accolades,allowance)/10),space,run.limit,7920)
            if run.quantity<1 then stop('No spendable accolades or Inventory capacity remains.');return end
            run.phase='quantity';run.deadline=now()+12;option(0x183,true)
        elseif run.phase=='quantity' then
            -- Prize Powder's quantity prompt: manual quantity, accolade-limited.
            -- Reject repeated allowance replies or unexpected menus rather than purchasing.
            if uint(data,4,4)~=0 or uint(data,8,4)~=99 then
                stop('Unexpected quantity prompt; no purchase sent.');return
            end
            local total,space=inventory()
            run.quantity=math.min(run.quantity,space)
            if run.quantity<1 then stop('Inventory filled before purchase; stopped.');return end
            run.baseline=total;run.phase='confirm';run.deadline=now()+15
            say('Requesting '..run.quantity..' Prize Powder for '..(run.quantity*10)..' accolades.')
            option(0x2000*run.quantity+0x184,true)
        elseif run.phase=='confirm' then
            close() -- One batch only. Never resend a purchase after a delayed response.
        end
    end
end)
windower.register_event('prerender',function()
    if not run then return end
    local info=windower.ffxi.get_info()
    if not info or not info.logged_in or info.zone~=230 then run=nil;return end
    if run.phase=='retry' then
        if now()<run.deadline then return end
        local p=windower.ffxi.get_player()
        local npc=windower.ffxi.get_mob_by_name('Urbiolaine')
        if not p or p.status~=0 or info.menu_open or not npc or npc.id~=run.id
            or not npc.valid_target or not npc.distance or npc.distance>36 then
            stop('Retry stopped: stand idle near Urbiolaine with menus closed. No purchase sent.');return
        end
        run.attempt=run.attempt+1;run.phase='menu';run.deadline=now()+12
        say('Retrying Urbiolaine contact (attempt '..run.attempt..' of 3).')
        packets.inject(packets.new('outgoing',0x01A,{['Target']=run.id,['Target Index']=run.index,['Category']=0}))
        return
    end
    if run.phase=='confirm' then
        local total=inventory()
        if total-run.baseline>=run.quantity then
            stop('Confirmed '..run.quantity..' Prize Powder added to Inventory.');return
        end
    end
    if now()>run.deadline then
        if run.phase=='menu' and run.attempt<3 then
            local p=windower.ffxi.get_player()
            local delay=3+((p and p.id or 0)%8)
            run.phase='retry';run.deadline=now()+delay
            say('No menu response; retrying in '..delay..' seconds. No purchase sent.')
        elseif run.phase=='confirm' then
            stop('Purchase confirmation timed out. Check Inventory before retrying; purchase will not be resent automatically.')
        else
            stop('Timed out during '..run.phase..'; no purchase sent. Contact attempts: '..run.attempt..'.')
        end
        return
    end
end)
windower.register_event('outgoing chunk',function(id,data,modified,injected)
    if run and not injected and (id==0x05B or id==0x01A) then
        run=nil;say('Manual interaction detected; automation stopped. Check Inventory if a purchase was sent.')
    end
end)
windower.register_event('zone change','logout',function() run=nil end)
windower.register_event('unload',function() if run then close();run=nil end end)
return M
