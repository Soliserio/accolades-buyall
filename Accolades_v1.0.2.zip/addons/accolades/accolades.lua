_addon.name = 'Accolades'
_addon.author = 'Soliserio'
_addon.version = '1.0.2'
_addon.commands = {'accolades', 'acco'}
local powder = require('prizepowder')
local function say(s) windower.add_to_chat(207, '[Accolades] '..s) end
windower.register_event('addon command', function(command, ...)
    command=(command or 'help'):lower()
    local args={...}
    local item=table.concat(args,' '):lower():gsub('%s+',' '):match('^%s*(.-)%s*$')
    if command=='cancel' or command=='stop' then powder.cancel();return end
    if command=='status' then say(powder.active() and 'Purchase in progress.' or 'Idle.');return end
    if (command=='buy' or command=='buyall') and item=='prize powder' then
        powder.start(command=='buy' and 1 or nil);return
    end
    say('Commands: //acco buy prize powder | //acco buyall prize powder | //acco cancel')
    say('Urbiolaine only. Uses Unity accolades, not Sparks. Do not run other NPC purchase addons at the same time.')
end)
windower.register_event('load',function()
    say('Loaded. Unity accolades only. Start with //acco buy prize powder for a one-item test.')
end)
